printf "cleaning up...\n"
rm DATA/pkl/*.*